/*global define*/
define( [], function () {
    'use strict';
    return {
        qHyperCubeDef: {
            qDimensions: [],
            qMeasures: [],
            qInitialDataFetch: [
                {
                    qWidth: 4,
                    qHeight: 2500
                }
            ]
        }
    };
} );
